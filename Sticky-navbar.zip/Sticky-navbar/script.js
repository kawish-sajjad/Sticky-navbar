jQuery(document).ready(function($){
	var name = $('.active').val();

	$(document).scroll(function () {
    	$(".header").toggleClass('fixed',$(document).scrollTop() > 50);
});
	$('.ham-menu').on('click', function (){
		$(".nav-atributs ul").toggle();
	});

	$('.nav-atributs li').on('click', function (){
		$(this).find(".nav-atributs ul").addClass("active");
	});
});